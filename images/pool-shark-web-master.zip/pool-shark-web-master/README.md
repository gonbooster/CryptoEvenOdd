# Shark of The Pool Web Application

This is a web application for Shark of The Pool Decentralized application.

It's made using React and Redux. User is required to have MetaMask extension.

### Dapp Demo
Demo of the application is available on [this address](http://34.210.217.34/)