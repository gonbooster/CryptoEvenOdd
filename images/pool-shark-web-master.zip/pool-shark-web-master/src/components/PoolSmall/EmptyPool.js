import React from 'react';

const EmptyPool = () => (
  <div className="text-center text-muted">
    There is no pools to show.
  </div>
);

export { EmptyPool };