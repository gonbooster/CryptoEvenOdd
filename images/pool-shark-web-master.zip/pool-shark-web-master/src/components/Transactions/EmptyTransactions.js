import React from 'react';

const EmptyTransactions = () => (
  <div className="text-center text-muted">
    There is no transactions to show.
  </div>
);

export { EmptyTransactions };